
boxxx - v1 2021-11-03 5:21pm
==============================

This dataset was exported via roboflow.ai on November 3, 2021 at 3:22 PM GMT

It includes 660 images.
Asd are annotated in Pascal VOC format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


